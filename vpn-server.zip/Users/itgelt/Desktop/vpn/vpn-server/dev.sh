#!/bin/bash

zip -r vpn-server.zip "$(realpath)"