sudo apt update
sudo apt install apache2 python3
sudo a2enmod cgi

current_path="$(pwd)"
cgi_path="$current_path/src/cgi"
cgi_conf="\<IfModule mod_alias.c\>\n\t\<IfModule mod_cgi.c\>\n\t\tDefine ENABLE_USR_LIB_CGI_BIN\n\t\</IfModule\>\n\n\t\<IfModule mod_cgid.c\>\n\t\tDefine ENABLE_USR_LIB_CGI_BIN\n\t\</IfModule\>\n\n\t\<IfDefine ENABLE_USR_LIB_CGI_BIN\>\n\t\tScriptAlias /api/ $cgi_path/\n\t\t\<Directory \"$cgi_path\"\>\n\t\t\tAllowOverride None\n\t\t\tOptions +ExecCGI -MultiViews +SymLinksIfOwnerMatch\n\t\t\tRequire all granted\n\t\t\</Directory\>\n\t\</IfDefine\>\n\</IfModule\>\n"
cgi_target_conf_path="/etc/apache2/conf-available/serve-cgi-bin.conf"

sudo echo $cgi_conf > $cgi_target_conf_path
sudo chmod -R 775 ./src/cgi/

sudo systemctl restart apache2