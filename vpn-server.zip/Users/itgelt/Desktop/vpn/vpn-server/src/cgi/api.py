#!/usr/bin/python3
print("Content-type: text/html\n\n")
print("<html><body><h1>Hello from CGI!</h1></body></html>")
