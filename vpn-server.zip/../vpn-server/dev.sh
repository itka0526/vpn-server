#!/bin/bash

zip -r vpn-server.zip ../vpn-server
